#include <stdio.h>
#include <stdint.h>

// Function implementing the pseudocode logic
unsigned int sqr_root(unsigned long long A) {
    unsigned long long D = A;
    unsigned long long R = 0;
    unsigned int Z = 0;
    unsigned int n = 32; // Assume maximum 64-bit input, so n = 32 bits for the root
    unsigned int i;

    for (i = n - 1; i < n; i--) { // Ensure proper unsigned loop behavior
        if (R >= 0) {
            R = R * 4 + (D >> (2 * n - 2)) - (4 * Z + 1);
        } else {
            R = R * 4 + (D >> (2 * n - 2)) + (4 * Z + 3);
        }

        if (R >= 0) {
            Z = 2 * Z + 1;
        } else {
            Z = 2 * Z;
        }

        D = D * 4;
    }

    return Z; // Final result
}

int main() {
    unsigned long long test_values[] = {0, 1, 4, 9, 16, 25, 100, 1024, 4294967296}; // Test inputs
    size_t num_tests = sizeof(test_values) / sizeof(test_values[0]);

    printf("Testing sqr_root function:\n");
    for (size_t i = 0; i < num_tests; i++) {
        unsigned long long input = test_values[i];
        unsigned int result = sqr_root(input);

        printf("Input: %llu, Computed Square Root: %u, Expected: %llu\n",
               input, result, (unsigned long long)sqrt(input));
    }

    return 0;
}
