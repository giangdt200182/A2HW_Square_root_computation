#include <stdio.h>
#include "system.h"

unsigned int *timer_status = ;
unsigned int *timer_control = ;
unsigned int *timer_periodl = ;
unsigned int *timer_periodh = ;
unsigned int *timer_snapl = ;
unsigned int *timer_snaph = ;

unsigned int timer_period;

void start_timer()
{
	*timer_control = 0x00000006;
}

unsigned int get_timer_period ()
{
	return ((((*timer_periodh)<<16))|(*timer_periodl&0xffff));
}

unsigned int get_timer_value ()
{
	*timer_snapl = 0;
	return (((*timer_snaph)<<16)|(*timer_snapl&0xffff));
}

unsigned int compute_time_interval(unsigned int v1, unsigned int v2)
{
	unsigned int time_interval;
	if (v1>=v2)
	{
		time_interval = v1-v2;
	}
	else
	{
		time_interval = v1 + timer_period - v2;
	}
	return time_interval;
}



int main()
{
	unsigned int first_value, second_value,restot;
	unsigned int tab_val[200];
	unsigned int tab_res[200];
	unsigned short i,j,k;
	
	printf("Hello from Nios II!\n");

	timer_period = get_timer_period();
	start_timer();

	first_value = get_timer_value();
	second_value = get_timer_value();

	printf("t1: %u, t2: %u, computation duration: %u\n",first_value,second_value,compute_time_interval(first_value,second_value));

  return 0;
}
